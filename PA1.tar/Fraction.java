class Fraction {

    private int top, bottom;

    //to string method used for printing
    public String toString(){
        reduce(); //call reduce before printing
        if (bottom == 0)	//if the denominator is 0 report Nan
            return ("NaN");

        else if (bottom == 1)	//if the denom is 1 only print the numerator
            return(top + " ");

        if (bottom < 0 && top > 0){	//if the denom is negative flip the negative sign
            top = top * -1;
            bottom = bottom * -1;
        }

        if (bottom < 0 && top < 0){	//if both parts are negative make both positive
            top = top * -1;
            bottom = bottom * -1;
        }
        return(top + " / " + bottom); //return fraction as a string
    }

    //constructor with two parameters
    Fraction(int num, int denom){
        top = num;
        bottom = denom;
    }

    //constructor with one parameter
    Fraction(int num){
        top = num;
        bottom = 1;
    }

    //default, shouldnt really be used
    Fraction(){
        top = bottom = 1;
    }

    //adding function. Uses the a/b + c/d = (ad+bc)/bd approach
    Fraction add(Fraction n){
        int denominator = bottom * n.getDenom();
        int numenator = (top * n.getDenom()) + (bottom * n.getNum());
        return(new Fraction(numenator,denominator));
    }
    //subtraction function. Uses the a/b - c/d = (ad-bc)/bd approach
    Fraction sub(Fraction n){
        int denominator = bottom * n.getDenom();
        int numenator = (top * n.getDenom()) - (bottom * n.getNum());
        return(new Fraction(numenator,denominator));
    }
    //multiplication function
    Fraction mul(Fraction n){
        int denominator, numenator;
        numenator = top * n.getNum();
        denominator = bottom * n.getDenom();
        return(new Fraction(numenator,denominator));
    }
    //multiplication function
    Fraction div(Fraction n){
        int denominator, numenator;
        numenator = top * n.getDenom();
        denominator = bottom * n.getNum();
        return(new Fraction(numenator,denominator));
    }

    //return top and bottom for internall use
    int getNum(){
        return (top);
    }
    int getDenom(){
        return (bottom);
    }
    //returns x as a double-precision floating point number
    double toDouble(){
        //double answer = (double)top / bottom;
        if (bottom == 0)
            return Double.NaN;
        return (double) top/bottom  ;//(answer);
    }
    //method to reduce fractions to the smallest factor
    void reduce(){
//get the gcd and divide top and bottom of the fraction
//with the gcd thus reducing it
        int gcd = gcd(top,bottom);
        top = top / gcd;
        bottom = bottom / gcd;

    }
    //calculate the greatest common denominator between two numbers
//using the Euclids algorithm recursively
    int gcd(int p, int q) {
        if (q == 0) return p;
        else return gcd(q, p % q);
    }
}
