//Name: Phu Pham
//Course: CSE223
//Comment: the Tic Tac Toe program playing with AI.
//--------------------------------------------------
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.*;
import static java.awt.Font.*;
// The import library

public class ABC { // the main program.
    public static void main(String[] args) { // The main function just call out all the program in JFrame.
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Tic();
            }
        });


    }
}
//-------------------------------------------------------
class Tic extends JFrame { // It will create Java Window

    private Container pane,pane1; //The pane
    private String currentPlayer; // Whose turn.
    private JButton[][] board; // The Array board

    private boolean Winner, FullBoard = false; // signal winer;
    private JMenuBar menuBar; // The menu bar on panel
    private JMenu File,New_Game,PvP,PvAI,X,Y; // The menu tab inside menubar
    private JMenuItem Start,X_AI,Y_AI,Y_Player,X_Player,Exit; //  The menu item.

    //-------------------------------------------------------------
    public Tic() { // Creating the background ,panel
        // Making a lable guide
        JLabel Guide = new JLabel("The Guide:You will compete with an AI, who take a line with 3 dots first-->Win.",JLabel.LEFT);
        Guide.setFont(new Font("serif", Font.PLAIN,20)); // THe font letter
        Guide.setForeground(Color.GREEN); // set the color
        Guide.setBounds(10, 11, 300, 30);
        JFrame frame= new JFrame ("Guide");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(Guide);
        frame.setSize(700,300); // The size of window
        frame.setVisible(true);
       //-------------------------
        //Making a pannel
        pane = getContentPane();
        pane.setLayout(new GridLayout(3, 3)); // Divide panel into 3 row 3 column
        setTitle("The Game: Tic Tac Toe"); // Set a title
        setSize(1000, 1000); // The size for a main panel
        setResizable(false);// cannot change the size
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);// CLose
        setVisible(true);
        currentPlayer = "X"; // set a current player as a string
        board = new JButton[3][3]; // This will allow we click on the grid panel
        Winner = false;// Set the winner false from  the begin.
        initBoard();// The board is set function to play
        initMenuBar();// The menubar is set
    }
//------------------------------------
    private void initMenuBar() { // menu bar to choose the option

        menuBar = new JMenuBar(); setJMenuBar(menuBar); // declare a menu bar

        File = new JMenu("File");menuBar.add(File); // declare a tab bar

        New_Game = new JMenu("New Game");File.add(New_Game);// inside the file, menu item


        PvP = new JMenu("PvP");New_Game.add(PvP); // it doesn't require to work so I skip it
        PvAI = new JMenu("PvAI"); New_Game.add(PvAI);// for PvAI

        X = new JMenu("Symbol: X");PvAI.add(X); // chose sympol X/O
        Y = new JMenu("Symbol: O");PvAI.add(Y);
//---------------------------------------------------------


        Exit = new JMenuItem("Exit");   // The exit to exit the program
        Exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });


        X_Player = new JMenuItem("Player First");X.add(X_Player); // to Start the game with X player start

        X_Player.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                resetX();


            }
        });
        Y_Player = new JMenuItem("Player First"); Y.add(Y_Player);// to Start the game with Y player start
        Y_Player.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                resetY(); // something here

            }
        });
        Y_AI = new JMenuItem("AI First"); Y.add(Y_AI);// to Start the game with Y AI start
        Y_AI.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                resetYA(); // something here

            }
        });
        X_AI = new JMenuItem("AI First"); X.add(X_AI);// to Start the game with X AI start
        X_AI.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                resetXA(); // something here

            }
        });    }

//--------------------------------------------------------

// These four of the reset determine different options from a player
    private void resetX() {   // X player first
        currentPlayer = "X";

        Winner = false;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j].setText("");
            }
        }
    }
    private void resetY() { // O player first
        currentPlayer = "O"; // X

        Winner = false;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j].setText("");
            }
        }
    }

    private void resetYA() { // O player first
        currentPlayer = "X"; //Computer
        Winner = false;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j].setText("");
            }
        }
        board[1][1].setText(currentPlayer); togglePlayer(); // make the computer first move in a middle which is more chance for computer to win
    }
    private void resetXA() { // X player first
        currentPlayer = "O"; //Computer
        Winner = false;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j].setText("");
            }
        }
        board[1][1].setText(currentPlayer); togglePlayer();// make the computer first move in a middle which is more chance for computer to win
    }
//-------------------------------------------------------


    private void initBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                JButton b = new JButton();
                b.setFont(new Font(SANS_SERIF, Font.CENTER_BASELINE, 300)); // make a X , O size and type font
                board[i][j] = b;

                b.addActionListener(new ActionListener() {
                    @Override

                    public void actionPerformed(ActionEvent e) {

                        if (((JButton) e.getSource()).getText().equals("") && !Winner) { // if not win yet

                            b.setText(currentPlayer); // set player as current person playing first
                            togglePlayer(); // then switch turn
                            AImove();
                            Winner(); // check winning

                            if (Winner == false) FullBoard(); // check full board for Draw
                        }
                    }
                });
                pane.add(b); // do it a gain.
            }
        }
    }

    private void togglePlayer() { // switch turn of players
        if (currentPlayer.equals("X"))
            currentPlayer = "O"; // AI
        else
            currentPlayer = "X"; // Human

    }


    private void FullBoard() { // We can see the board as a diagram below
        String one = board[0][0].getText();   //     1[0,0]   2[0,1]    3[0,2]
        String two = board[0][1].getText();   //    4[1,0]   5[1,1]    6[1,2]
        String three = board[0][2].getText();//    7[2,0]   8[2,1]    9[2,2]
        String four = board[1][0].getText();
        String five = board[1][1].getText();
        String six = board[1][2].getText();
        String seven = board[2][0].getText();
        String eight = board[2][1].getText();
        String nine = board[2][2].getText();
        if (!one.isEmpty() && !two.isEmpty() && !three.isEmpty() && !four.isEmpty() && !five.isEmpty() && !six.isEmpty() && !seven.isEmpty() && !eight.isEmpty() && !nine.isEmpty()) {
            // It will show The Draw match if all 9 grids are full.
            JOptionPane.showConfirmDialog(null, "Draw");
            FullBoard = true; // return true
        }
    }

    private void Winner() { // Check winner based on 8 ways and declare.
        String one = board[0][0].getText();   //     1[0,0]   2[0,1]    3[0,2]
        String two = board[0][1].getText();   //    4[1,0]   5[1,1]    6[1,2]
        String three = board[0][2].getText();//    7[2,0]   8[2,1]    9[2,2]
        String four = board[1][0].getText();
        String five = board[1][1].getText();
        String six = board[1][2].getText();
        String seven = board[2][0].getText();
        String eight = board[2][1].getText();
        String nine = board[2][2].getText();
        if (one.equals(currentPlayer) && two.equals(currentPlayer) && three.equals(currentPlayer)) {
            JOptionPane.showConfirmDialog(null, "Player " + currentPlayer + " won the game");
            Winner = true;
        }
        if (four.equals(currentPlayer) && five.equals(currentPlayer) && six.equals(currentPlayer)) {
            JOptionPane.showConfirmDialog(null, "Player " + currentPlayer + " won the game");
            Winner = true;
        }
        if (seven.equals(currentPlayer) && eight.equals(currentPlayer) && nine.equals(currentPlayer)) {
            JOptionPane.showConfirmDialog(null, "Player " + currentPlayer + " won the game");
            Winner = true;
        }
        if (one.equals(currentPlayer) && four.equals(currentPlayer) && seven.equals(currentPlayer)) {
            JOptionPane.showConfirmDialog(null, "Player " + currentPlayer + " won the game");
            Winner = true;
        }
        if (two.equals(currentPlayer) && five.equals(currentPlayer) && eight.equals(currentPlayer)) {
            JOptionPane.showConfirmDialog(null, "Player " + currentPlayer + " won the game");
            Winner = true;
        }
        if (three.equals(currentPlayer) && six.equals(currentPlayer) && nine.equals(currentPlayer)) {
            JOptionPane.showConfirmDialog(null, "Player " + currentPlayer + " won the game");
            Winner = true;
        }
        if (one.equals(currentPlayer) && five.equals(currentPlayer) && nine.equals(currentPlayer)) {
            JOptionPane.showConfirmDialog(null, "Player " + currentPlayer + " won the game");
            Winner = true;
        }
        if (seven.equals(currentPlayer) && five.equals(currentPlayer) && three.equals(currentPlayer)) {
            JOptionPane.showConfirmDialog(null, "Player " + currentPlayer + " won the game");
            Winner = true;
        }

    }

    void AImove() { // The AI move
        String one = board[0][0].getText();   //     1[0,0]   2[0,1]    3[0,2]
        String two = board[0][1].getText();   //    4[1,0]   5[1,1]    6[1,2]
        String three = board[0][2].getText();//    7[2,0]   8[2,1]    9[2,2]
        String four = board[1][0].getText();
        String five = board[1][1].getText();
        String six = board[1][2].getText();
        String seven = board[2][0].getText();
        String eight = board[2][1].getText();
        String nine = board[2][2].getText();

// To deal it with for loop of random and avoid winner and fullboard.
        for (int i = ran(0,2);!Winner||!FullBoard;i = ran(0,2)) {
            for (int j = ran(0,2); !Winner||!FullBoard;j = ran(0,2),i=ran(0,2)) {

                Winner(); // check winner // it may unnecessary here
                if (board[i][j].getText().isEmpty()) { // check the first time
                    board[i][j].setText(currentPlayer);
                    System.out.println(" tick");
                    togglePlayer();break;
                }
                        // If it duplicate the same grid make a loop to find a different one to choose. This part is the hardest one, it wasted me 6 hours to figure out.
                while(!board[i][j].getText().equals("X")||!board[i][j].getText().equals("O")&&(Winner||FullBoard)) { // the condition
                    System.out.println("fail"); // optional to check if AI turn to the same place

                    if ((board[i][j].getText().equals("X")||board[i][j].getText().equals("O"))&&(!Winner||!FullBoard)){
                        j = ran(0,2);i=ran(0,2);  // make the other random place for column and row
                        System.out.println(" tick2"); // check if it work
                        break;  }
                    board[i][j].setText(currentPlayer); //if everything in a loop fine, set the AI in

                }
            }   break; //get out immediately when the AI mark.

        }}


    int ran(int min,int max) { // the random function fluctuate between 0 and 2.
        int range=(max-min)+1;
        return (int)(Math.random()*range)+min;
    }
}